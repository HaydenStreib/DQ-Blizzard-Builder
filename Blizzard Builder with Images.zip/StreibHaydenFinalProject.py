#Hayden Streib
#3/6/2024
#Final Project Blizzard Builder
#This program is a Blizzard Builder for Diary Queen and will allow the user to pick their size, soft serve flavor, toppings and their final result.
#Importing tkinter and messagebox
import tkinter as tk
from tkinter import messagebox
#define the start menu and add labels, images and the start and exit buttons
def start_menu():
    start_window = root
    start_window.title("DQ Blizzard Builder")
    #use the images dictionairy to call the logo for the start window
    start_image_label = tk.Label(start_window, image=images["Logo"])
    start_image_label.pack()
    start_label = tk.Label(start_window, text = "Welcome to the Dairy Queen Blizzard Builder")
    start_label.pack()
    #set commands for each button
    start_button = tk.Button(start_window, text = "Start", command = select_size)
    start_button.pack()
    exit_button = tk.Button(start_window, text = "Exit", command = exit)
    exit_button.pack()
#after clicking the start button, the select size function will be called and a new window will open
def select_size():
    size_window = tk.Toplevel(root)
    size_window.title("Select Your Blizzard Size")
    size_label = tk.Label(size_window, text = "pick your size")
    size_label.pack()
    #add a variable where the buttons will store their value, if selected. 
    size_var = tk.StringVar()
    mini_btn = tk.Radiobutton(size_window, text = "Mini", variable = size_var, value = "Mini")
    mini_btn.config(image = images["Mini"])
    mini_btn.pack()
    small_btn = tk.Radiobutton(size_window, text = "Small", variable = size_var, value = "Small")
    small_btn.config(image = images["Small"])
    small_btn.pack()
    medium_btn = tk.Radiobutton(size_window, text = "Medium", variable = size_var, value = "Medium")
    medium_btn.config(image = images["Medium"])
    medium_btn.pack()
    large_btn = tk.Radiobutton(size_window, text = "Large", variable = size_var, value = "Large")
    large_btn.config(image = images["Large"])
    large_btn.pack()
    #set the command for the next button as a callback to verify if a size was selected or not
    next_button = tk.Button(size_window, text = "Next", command = lambda: check_size(size_window, size_var))
    next_button.pack()
    exit_button = tk.Button(size_window, text = "Exit", command = exit)
    exit_button.pack()
    #Ensure the user can only interact with this window
    size_window.grab_set()
#define the check size function
def check_size(size_window, size_var):
    #assign the selected size as the size_var
    selected_size = size_var.get()
    #add a warning message box if selected_size == ""
    if selected_size == "":
        messagebox.showwarning("Size not selected", "Please select size", parent=size_window)
    else:
        #add size to the blizzard dictionary and close the window
        blizzard["size"] = selected_size
        size_window.destroy()
        select_flavor()
#define the select flavor function and add two buttons for chocolate and vanilla
def select_flavor():
    flavor_window = tk.Toplevel(root)
    flavor_window.title("Select Your Soft Serve Flavor")
    flavor_label = tk.Label(flavor_window, text = "Choose Your Soft Serve Flavor")
    flavor_label.pack()
    flavor_var = tk.StringVar()
    chocolate_btn = tk.Radiobutton(flavor_window, text = "chocolate", variable = flavor_var, value = "chocolate")
    #add an image for chocolate using data from the image dictionary
    chocolate_btn.config(image = images["Chocolate"])
    chocolate_btn.pack()
    #set up the twist button and image
    twist_btn = tk.Radiobutton(flavor_window, text = "twist", variable = flavor_var, value = "twist")
    twist_btn.config(image = images["Twist"])
    twist_btn.pack()
    vanilla_btn = tk.Radiobutton(flavor_window, text = "vanilla", variable = flavor_var, value = "vanilla")
    #add the vanilla image as well
    vanilla_btn.config(image= images["Vanilla"])
    vanilla_btn.pack()
    #the Next button, again, will check if the user picked a flavor or not
    next_button = tk.Button(flavor_window, text = "Next", command = lambda: check_flavor(flavor_window, flavor_var))
    next_button.pack()
    exit_button = tk.Button(flavor_window, text = "Exit", command = exit)
    exit_button.pack()
    flavor_window.grab_set()
#this function will check if a flavor was chosen or not as well as assign the flavor to the blizzard dictionary, then close the window
def check_flavor(flavor_window, flavor_var):
    selected_flavor = flavor_var.get()
    if selected_flavor == "":
        messagebox.showwarning("Flavor not selected", "Please select flavor", parent=flavor_window)
    else:
        blizzard["flavor"] = selected_flavor
        flavor_window.destroy()
        select_toppings()
#define the topping selection function to handle listbox selection and storing 
def topping_selection(event):
    #turn the list box into an event widget to track the current selection(s)
    toppings_listbox = event.widget
    #after the user picks a topping, the current selection will be set as the selected topping
    selected_toppings = toppings_listbox.curselection()
    #build a list of selected toppings to be added to the blizzard dictionary
    blizzard["toppings"] = [toppings_listbox.get(i) for i in selected_toppings]
#define another function for selecting toppings using a list box instead of radio buttons
def select_toppings():
    toppings_window = tk.Toplevel(root)
    toppings_window.geometry("200x425")
    toppings_window.title("Select your Blizzard Toppings")
    toppings_label = tk.Label(toppings_window, text = "Pick your Toppings")
    toppings_label.pack()
    #create a list box widget that allows for multiple toppings
    toppings_listbox = tk.Listbox(toppings_window, selectmode=tk.MULTIPLE)
    #insert candy options into listbox
    toppings_listbox.insert(tk.END, "hot caramel")
    toppings_listbox.insert(tk.END, "marshmallow")
    toppings_listbox.insert(tk.END, "graham cracker")
    toppings_listbox.insert(tk.END, "sprinkles")
    toppings_listbox.insert(tk.END, "mint")
    toppings_listbox.insert(tk.END, "pineapple")
    toppings_listbox.insert(tk.END, "cherry")
    toppings_listbox.insert(tk.END, "cocoa fudge")
    toppings_listbox.insert(tk.END, "oreo")
    toppings_listbox.insert(tk.END, "whipped cream")
    toppings_listbox.insert(tk.END, "reeses")
    toppings_listbox.insert(tk.END, "snickers")
    toppings_listbox.insert(tk.END, "strawberry")
    toppings_listbox.insert(tk.END, "hot fudge")
    toppings_listbox.insert(tk.END, "heath bar")
    toppings_listbox.insert(tk.END, "butter finger")
    toppings_listbox.insert(tk.END, "cookie dough")
    toppings_listbox.insert(tk.END, "brownie bites")
    toppings_listbox.insert(tk.END, "chocolate chunks")
    toppings_listbox.insert(tk.END, "cheese cake")
    #bind a callback to the list box select event so that chosen toppings can be stored
    toppings_listbox.bind("<<ListboxSelect>>", topping_selection)
    #while packing, you can adjust the width and height so the user can see the entire list without scrolling
    toppings_listbox.pack(padx=10, pady=10, fill="both", expand = True)
    #create another set of exit and next buttons. The next button will check if any toppings were selected
    next_button = tk.Button(toppings_window, text = "Complete your Order", command = lambda: check_toppings(toppings_window))
    next_button.pack()
    exit_button = tk.Button(toppings_window, text = "Exit", command = exit)
    exit_button.pack()
    toppings_window.grab_set()
#define another function to test if any toppings where selected or not
def check_toppings(toppings_window):
    #check if any toppings have been added to the blizzard dictionary
    if "toppings" in blizzard.keys():
        selected_toppings = blizzard["toppings"]
    else:
        selected_toppings = False
    #if no toppings were selected, display another warning message
    if not selected_toppings:
        messagebox.showwarning("Toppings not selected", "Please select toppings", parent=toppings_window)
    else:
        #close the window and show the order
        toppings_window.destroy()
        show_order()
#shows a summary of your complete order 
def show_order():
    order_window = tk.Toplevel(root)
    order_window.title("Your completed Blizzard")
    #create the cost of each blizzard size
    if blizzard["size"] == "Mini":
        cost = "4.96"
    elif blizzard["size"] == "Small":
        cost = "5.50"
    elif blizzard["size"] == "Medium":
        cost = "6.15"
    else:
        cost = "7.12"
    #format the completed order and the total cost with each topping seperated by a comma
    order_text = "Total: " + cost + "\n" + "Size: " + blizzard["size"] + "\n" \
        + "Flavor: " + blizzard["flavor"] + "\n" \
        + "Toppings: " + ", ".join(blizzard["toppings"])
    #create a message widget to display order summary
    order_msg = tk.Message(order_window, text=order_text, width=200)
    order_msg.pack()
    #add a final exit button
    exit_button = tk.Button(order_window, text = "Exit", command = exit)
    exit_button.pack()
    order_window.grab_set()
#Global reference to the main tkinter window
root = tk.Tk()
#first dictonairy used for storing images so that the program always has a reference for each picture
images = {}
images["Logo"] = tk.PhotoImage(file="dqlogo.png")
images["Chocolate"] = tk.PhotoImage(file = "chocolate.png")
images["Vanilla"] = tk.PhotoImage(file = "vanilla.png")
images["Mini"] = tk.PhotoImage(file = "mini.png")
images["Small"] = tk.PhotoImage(file = "small.png")
images["Medium"] = tk.PhotoImage(file = "medium.png")
images["Large"] = tk.PhotoImage(file = "large.png")
images["Twist"] = tk.PhotoImage(file = "twist.png")
#second dictonairy used for storing size, flavor, and each topping. This dictionary will also be used when showing the order
blizzard = {}
start_menu()
root.mainloop()
